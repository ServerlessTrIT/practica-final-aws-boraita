import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { MatListOption } from '@angular/material/list';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor() { }
  users;
  userInvalid = false;

  form = new FormGroup({
    name: new FormControl(''),
    surname: new FormControl(''),
    gender: new FormControl('')
  });
  userSelected;

  ngOnInit(): void {
    this.users = [{
      name: 'Rafa',
      surname: 'Mon',
      gender: 'M'
    }, {
      name: 'Ele',
      surname: 'Agui',
      gender: 'F'
    }, {
      name: 'Alan',
      surname: 'Poe',
      gender: 'M'
    }, {
      name: 'Poldi',
      surname: 'Mol',
      gender: 'M'
    }];
  }
  onSubmit() {
    if (this.form.valid) {

    }
  }

  selectUser(user: MatListOption) {
    this.userSelected = user[0];
  }

}
