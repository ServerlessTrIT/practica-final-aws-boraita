import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-validate',
  templateUrl: './validate.component.html',
  styleUrls: ['./validate.component.scss']
})
export class ValidateComponent {

  loginInvalid: boolean;
  form = new FormGroup({
    username: new FormControl(''),
    number: new FormControl('')
  });

  constructor(private authService: AuthService) { }

  submit() {
    this.loginInvalid = false;
    if (this.form.valid) {
      this.authService.login(this.form.get('username').value, this.form.get('number').value).subscribe();
    }
  }

}
