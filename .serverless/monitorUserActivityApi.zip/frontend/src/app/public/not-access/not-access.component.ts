import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-not-access',
	templateUrl: './not-access.component.html'
})
export class NotAccessComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
