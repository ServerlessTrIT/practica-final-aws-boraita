export enum keys{
  API_KEY = 'NFNQrMOrU71FoXJ9uQXgO5WYrmmIqJmB25ykkzsb',
  AUTH_API = 'https://gvqv1uptoe.execute-api.eu-central-1.amazonaws.com/dev/'
}
