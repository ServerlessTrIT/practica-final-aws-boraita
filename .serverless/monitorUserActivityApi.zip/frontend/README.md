# MonitorUserActivity

Importante!

Crear archivo en core/credentials.ts

export enum keys{
  API_KEY = 'XXXXXXXXXX',
  AUTH_API = 'XXXXXXXX.eu-central-1.amazonaws.com/dev/'
}

